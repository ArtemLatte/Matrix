#include <iostream>
#include <time.h>
#include <cmath>
#include <vector>

vector<vector<double>> GetMinor(int index_lines, int index_column, vector<vector<double>> matrix_A)   // возвращает минор матрицы
{
    vector<vector<double>> Minor;
    for (int i = 0; i < matrix_A.size(); i++)
    {
        if (i != index_lines)
        {
            vector<double> current_len;
            for (int j = 0; j < matrix_A[i].size(); j++)
            {
                if (j != index_column)
                {
                    current_len.push_back(matrix_A[i][j]);
                }
            }
            Minor.push_back(current_len);
        }
    }
    return Minor;
}
double Determinant2x2(vector<vector<double>> cur_minor)
{
    return ((cur_minor[0][0] * cur_minor[1][1]) - (cur_minor[0][1] * cur_minor[1][0]));
}
double Determinant(vector<vector<double>> slay_a, int slay_lines, int slay_n)   // возвращает детерменант матрицы
{
    if (slay_lines == 1 && slay_n == 1)
    {
        return slay_a[0][0];
    }
    double det_A = 0.0;
    vector<vector<double>> minor = slay_a;
    for (int i = 0; i < slay_n; i++)
    {
        if (minor.size() == 2 && minor[0].size() == 2)
        {
            return Determinant2x2(minor);
        }
        if (minor.size() > 2)
        {
            for (int i = 0; i < slay_n; i++)
            {
                vector<vector<double>> minor = GetMinor(0, i, slay_a);
                det_A += pow(-1, i) * slay_a[0][i] * Determinant(minor, minor.size(), minor[0].size());
            }
            return det_A;
        }
    }
    return det_A;
}
vector<vector<double>> MatrixAlgebraiComplement(vector<vector<double>> slay_a, int slay_lines, int slay_n)
{
    vector<vector<double>> matrixAlgebraiComplement;
    for (int i = 0; i < slay_n; i++)
    {
        vector<double> cur_matrixAlgebraiComplement;
        for (int j = 0; j < slay_lines; j++)
        {
            vector<vector<double>> minor = GetMinor(i, j, slay_a);
            cur_matrixAlgebraiComplement.push_back(pow(-1, i+j) * Determinant(minor, minor.size(), minor[0].size()));
        }
        matrixAlgebraiComplement.push_back(cur_matrixAlgebraiComplement);
    }
    return matrixAlgebraiComplement;
}
vector<vector<double>> Transposition(vector<vector<double>> slay_a, int slay_lines, int slay_n)
{
    vector<vector<double>> transposition;
    for (int i = 0; i < slay_n; i++)
    {
        vector<double> cur_transposition;
        for (int j = 0; j < slay_lines; j++)
        {
            cur_transposition.push_back(slay_a[j][i]);
        }
        transposition.push_back(cur_transposition);
    }
    return transposition;
}
vector<double> MatrixMultiplication(double det_A, vector<vector<double>> matrix_a, vector<double> matrix_b)
{
    if (matrix_a[0].size() != matrix_b.size())
    {
        vector<double> result(-1);
        return result;
    }
    vector<double> matrixMultiplication;
    for (int i = 0; i < matrix_a.size(); i++)
    {
        double cur_sum = 0.0;
        for (int k = 0; k < matrix_a[i].size(); k++)
        {
            cur_sum += matrix_a[i][k] * matrix_b[k];
        }
        matrixMultiplication.push_back((1.0 / det_A) * cur_sum);
    }
    return matrixMultiplication;
}